CREATE VIEW v_politicalpart AS
  SELECT
    if((`db_school`.`t_politicalpart`.`politicalpart_school` <> ''), '校',
       if((`db_school`.`t_politicalpart`.`politicalpart_county` <> ''), '区',
          if((`db_school`.`t_politicalpart`.`politicalpart_city` <> ''), '市',
             if((`db_school`.`t_politicalpart`.`politicalpart_province` <> ''), '省',
                if((`db_school`.`t_politicalpart`.`politicalpart_country` <> ''), '全国', ''))))) AS `politicalpart_type`,
    `db_school`.`t_politicalpart`.`person_id`                                                   AS `person_id`,
    `db_school`.`t_politicalpart`.`politicalpart_country`                                       AS `politicalpart_country`,
    `db_school`.`t_politicalpart`.`politicalpart_province`                                      AS `politicalpart_province`,
    `db_school`.`t_politicalpart`.`politicalpart_city`                                          AS `politicalpart_city`,
    `db_school`.`t_politicalpart`.`politicalpart_county`                                        AS `politicalpart_county`,
    `db_school`.`t_politicalpart`.`politicalpart_school`                                        AS `politicalpart_school`,
    `db_school`.`t_politicalpart`.`politicalpart_times`                                         AS `politicalpart_times`,
    `db_school`.`t_politicalpart`.`politicalpart_position`                                      AS `politicalpart_position`,
    `db_school`.`t_politicalpart`.`politicalpart_start_time`                                    AS `politicalpart_start_time`,
    `db_school`.`t_politicalpart`.`politicalpart_end_time`                                      AS `politicalpart_end_time`
  FROM `db_school`.`t_politicalpart`;
