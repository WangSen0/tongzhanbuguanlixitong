CREATE VIEW v_deputypeople AS
  SELECT
    if((`db_school`.`t_deputypeople`.`deputypeople_county` <> ''), '区',
       if((`db_school`.`t_deputypeople`.`deputypeople_city` <> ''), '市',
          if((`db_school`.`t_deputypeople`.`deputypeople_province` <> ''), '省',
             if((`db_school`.`t_deputypeople`.`deputypeople_country` <> ''), '全国', '')))) AS `deputypeople_type`,
    `db_school`.`t_deputypeople`.`person_id`                                              AS `person_id`,
    `db_school`.`t_deputypeople`.`deputypeople_country`                                   AS `deputypeople_country`,
    `db_school`.`t_deputypeople`.`deputypeople_province`                                  AS `deputypeople_province`,
    `db_school`.`t_deputypeople`.`deputypeople_city`                                      AS `deputypeople_city`,
    `db_school`.`t_deputypeople`.`deputypeople_county`                                    AS `deputypeople_county`,
    `db_school`.`t_deputypeople`.`deputypeople_times`                                     AS `deputypeople_times`,
    `db_school`.`t_deputypeople`.`deputypeople_start_time`                                AS `deputypeople_start_time`,
    `db_school`.`t_deputypeople`.`deputypeople_end_time`                                  AS `deputypeople_end_time`
  FROM `db_school`.`t_deputypeople`;
