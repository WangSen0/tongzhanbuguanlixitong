CREATE VIEW v_unitedpart AS
  SELECT
    if((`db_school`.`t_unitedpart`.`unitedpart_school` <> ''), '校',
       if((`db_school`.`t_unitedpart`.`unitedpart_county` <> ''), '区',
          if((`db_school`.`t_unitedpart`.`unitedpart_city` <> ''), '市',
             if((`db_school`.`t_unitedpart`.`unitedpart_province` <> ''), '省',
                if((`db_school`.`t_unitedpart`.`unitedpart_country` <> ''), '全国', ''))))) AS `unitedpart_type`,
    `db_school`.`t_unitedpart`.`person_id`                                                AS `person_id`,
    `db_school`.`t_unitedpart`.`unitedpart_country`                                       AS `unitedpart_country`,
    `db_school`.`t_unitedpart`.`unitedpart_province`                                      AS `unitedpart_province`,
    `db_school`.`t_unitedpart`.`unitedpart_city`                                          AS `unitedpart_city`,
    `db_school`.`t_unitedpart`.`unitedpart_county`                                        AS `unitedpart_county`,
    `db_school`.`t_unitedpart`.`unitedpart_school`                                        AS `unitedpart_school`,
    `db_school`.`t_unitedpart`.`unitedpart_times`                                         AS `unitedpart_times`,
    `db_school`.`t_unitedpart`.`unitedpart_position`                                      AS `unitedpart_position`,
    `db_school`.`t_unitedpart`.`unitedpart_start_time`                                    AS `unitedpart_start_time`,
    `db_school`.`t_unitedpart`.`unitedpart_end_time`                                      AS `unitedpart_end_time`
  FROM `db_school`.`t_unitedpart`;
