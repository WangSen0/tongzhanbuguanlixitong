CREATE VIEW v_politicalconsult AS
  SELECT
    if((`db_school`.`t_politicalconsult`.`politicalconsult_county` <> ''), '区',
       if((`db_school`.`t_politicalconsult`.`politicalconsult_city` <> ''), '市',
          if((`db_school`.`t_politicalconsult`.`politicalconsult_province` <> ''), '省',
             if((`db_school`.`t_politicalconsult`.`politicalconsult_country` <> ''), '全国',
                ''))))                                             AS `politicalconsult_type`,
    `db_school`.`t_politicalconsult`.`person_id`                   AS `person_id`,
    `db_school`.`t_politicalconsult`.`politicalconsult_country`    AS `politicalconsult_country`,
    `db_school`.`t_politicalconsult`.`politicalconsult_province`   AS `politicalconsult_province`,
    `db_school`.`t_politicalconsult`.`politicalconsult_city`       AS `politicalconsult_city`,
    `db_school`.`t_politicalconsult`.`politicalconsult_county`     AS `politicalconsult_county`,
    `db_school`.`t_politicalconsult`.`politicalconsult_times`      AS `politicalconsult_times`,
    `db_school`.`t_politicalconsult`.`politicalconsult_start_time` AS `politicalconsult_start_time`,
    `db_school`.`t_politicalconsult`.`politicalconsult_end_time`   AS `politicalconsult_end_time`
  FROM `db_school`.`t_politicalconsult`;
